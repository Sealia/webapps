from django.apps import AppConfig


class BiotoolsConfig(AppConfig):
    name = 'biotools'
