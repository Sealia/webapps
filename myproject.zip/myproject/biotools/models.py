from django.db import models

# class Method(models.Model):
# 	methods=(('reverse complement','reverse complement' ),('reverse', 'reverse'),('complement','complement'))

# 	title=models.CharField(max_length = 100, choices=methods)
# Create your models here.
